# ICONNET Landing (Static)

- Instagram: https://instagram.com/hasyimmmramonnn_
- WhatsApp: https://wa.me/6281572176223

## Deploy ke Vercel (GitHub)
1. Buat repo baru dan push folder ini.
2. Di Vercel, **New Project** → pilih repo.
3. Framework: **Other** (Static).
4. Root directory: **/** (biarkan default).
5. Build command: *(kosongkan)* — ini situs statis.
6. Output directory: *(kosongkan)*.
7. Deploy.

## Deploy ke Vercel (CLI)
```bash
npm i -g vercel
vercel login
vercel deploy --prod
```
